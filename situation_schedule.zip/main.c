// 0황지훈, 1변희원, 2한철웅, 3김동수, 4유창우, 5허정현, 6심혁, 7최선웅, 8민준식, 9김태언, 10최혁, 11박종선, 12장건, 13이일희, 14박건
#include <stdio.h>
#include <string.h>
#define num 15


typedef struct situation_worker {

    int score;
    int outing;
    struct situation_worker* next;
    
}STRUCT;

int main()
{
    STRUCT worker_imfo[num];
    
    for(int i=0; i<num ; i++) {
        worker_imfo[i].next = &worker_imfo[++i];
    }
    
    

    return 0;
}

